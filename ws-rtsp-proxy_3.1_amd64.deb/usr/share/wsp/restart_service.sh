#!/bin/bash

# You must have the superuser permissions to run the current script
if [ "$EUID" -ne 0 ]
  then echo "Please run as root"
  exit
fi

echo "Trying to stop..."
systemctl stop ws_rtsp

echo "Trying to start..."
systemctl start ws_rtsp

echo ""
echo "Press any key to continue..."  #'-n' means do not add \n to end of string
read -n1 any_key

exit 0
